package ics202.lab02;

import ics202.*;
import ics202.lab01.*;

public class MySearchableContainer extends MyContainer implements SearchableContainer {
	
	private int findIndex(MyComparable target) {
		int pos = 0;
		while (pos < count && !list[pos].equals(target)) 
			pos++;
		if (pos < count)  //then target is found
			return pos;
		else
			return -1;
	}
	
	public void withdraw(MyComparable target) {
		int index = findIndex(target);
		if (index != -1) {  //the target exists
			for (int i=index; i<count-1; i++)
				list[i] = list[i+1];
			count--;
		}
	}

	//returns the reference to the target if found, null otherwise 
	public MyComparable find(MyComparable target) {
	    if(findIndex(target)!=-1)
	           return list[findIndex(target)];
        return null;
	}
	
    //returns true if target is in the container, false otherwise.	
	public boolean isMember(MyComparable target) {
		if(findIndex(target)!=-1)
		     return true;
		else
		     return false; 
	}
	
}			