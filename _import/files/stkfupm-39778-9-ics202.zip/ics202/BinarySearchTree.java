package ics202;


public class BinarySearchTree extends BinaryTree implements SearchTree
{
    private BinarySearchTree getLeftBST()
    {
        return (BinarySearchTree)getLeft();
    }

    private BinarySearchTree getRightBST()
    {
        return (BinarySearchTree)getRight();
    }

    public boolean isMember(MyComparable comparable)
    {
        if(find(comparable) == null)
    	   return false ;
    	else
    	   return true;
    }

    public MyComparable find(MyComparable comparable)
    {
        if(isEmpty())
            return null;
        MyComparable key = (MyComparable) getKey();    
        if(comparable.isEQ(key))
            return key;
        else if (comparable.isLT(key))
            return getLeftBST().find(comparable);
        else    
            return getRightBST().find(comparable);
    }
    
    
    public MyComparable findMin()
    {
        if(isEmpty())
            return null;
        if(getLeftBST().isEmpty())
            return (MyComparable)getKey();
        else
            return getLeftBST().findMin();
    }
    
    
    public MyComparable findMax()
    {
        if(isEmpty())
            return null;
        if(getRightBST().isEmpty())
            return (MyComparable)getKey();
        else
            return getRightBST().findMax();
    }

    public void attachKey(Object obj)
    {
        if(!isEmpty())
            throw new InvalidOperationException();
        else
        {
            key = obj;
            left = new BinarySearchTree();
            right = new BinarySearchTree();
        }
    }

    public void insert(MyComparable comparable)
    {
        if(isEmpty())
            attachKey(comparable);
        else
        {
         	MyComparable key = (MyComparable) getKey();    
        	if(comparable.isEQ(key))
                throw new IllegalArgumentException("duplicate key");
        	else if (comparable.isLT(key))
                getLeftBST().insert(comparable);
        	else    
                getRightBST().insert(comparable);

        }
    }
    
    
    public void withdraw(MyComparable comparable)
    {
       if(isEmpty( ))
            throw new IllegalArgumentException("object notfound") ;
            
	   MyComparable key = (MyComparable) getKey( ) ;    
       if(comparable.isLT(key))
            getLeftBST( ).withdraw(comparable) ;
        else if(comparable.isGT(key))
            getRightBST( ).withdraw(comparable) ;
       else
       { // the key is found
          if(isLeaf())   
             detachKey( ) ;
          else if( ! getLeftBST().isEmpty())
          {
              MyComparable max = getLeftBST().findMax() ;
              super.key = max ;    
              getLeftBST( ).withdraw(max) ; 
          }
          else 
          { // the right subtree is not empty
              MyComparable min = getRightBST().findMin() ;
              super.key = min ;    
              getRightBST().withdraw(min) ; 
          }
       }
    }
    public int getCount()
      {
      	if(isEmpty())
      	   return 0;
      	if(isLeaf())
      	   return 1;
      	else 
      	   return 1+ getLeftBST().getCount()+getRightBST().getCount();
      }
      
    public int leavesCount()
      {
      	if(isEmpty())
            throw new IllegalArgumentException("Tree is empty");
        if(isLeaf())
            return 1;
        else 
            return getLeftBST().leavesCount()+getRightBST().leavesCount();
      }
    public int depth(MyComparable x)
      {
      	if(isEmpty())
      	    throw new IllegalArgumentException("Object not included");
      	if(x.isEQ((MyComparable)getKey()))
      	    return 0;
      	else if(x.isLT((MyComparable)getKey()))
      	    return 1+getLeftBST().depth(x);
      	else
      	    return 1+getRightBST().depth(x);
      }
    public int width()
      {
      	if(isEmpty())
      	     throw new IllegalArgumentException("Tree is empty");
      	int depth=depth((MyComparable)getKey());
      	QueueAsLinkedList queue=new QueueAsLinkedList();
      	MyLinkedList list=new MyLinkedList();
      	int max=0;
      	queue.enqueue(this);
      	while(!queue.isEmpty())
      	     {
      	     	BinarySearchTree tree=(BinarySearchTree)queue.dequeue();
      	     	for(int i=0;i<tree.getDegree();i++)
      	     	    {
      	     	    	Tree tree1=tree.getSubtree(i);
      	     	    	if(!tree1.isEmpty())
      	     	    	     queue.enqueue(tree1);
      	     	    }
      	     	list.append(tree);
      	     }
      	 for(int j=0;j<=getHeight();j++)
      	     {
      	     	int count=0;
      	     	boolean done=false;
      	     	while(!done && !list.isEmpty())
      	     	   {
      	     	   	  BinarySearchTree tree=(BinarySearchTree)list.getFirst();
      	     	   	  if(j==depth((MyComparable)tree.getKey()))
      	     	   	       {
      	     	   	       	  count++;
      	     	   	       	  list.extract(tree);
      	     	   	          if(list.isEmpty())
      	     	   	              done=true;
      	     	   	       }
      	     	   	  else
      	     	   	      done=true;
      	     	   }
      	     	 if(count>max)
      	     	      max=count;
      	     }
      	  return max;
       }
    public boolean isFull()
       { 	 
      	  return width()==Math.pow(2,getHeight());
       }    	
} 
