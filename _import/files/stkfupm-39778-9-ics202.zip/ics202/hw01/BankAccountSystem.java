package ics202.hw01;

import ics202.lab01.*;
import ics202.*;

import java.io.*;

public class BankAccountSystem
{
 public static void main(String[] args)throws IOException
    { 
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        MyContainer container=new MyContainer();
        boolean done=false;
        int number=0;
        boolean finish=false;
        while(!finish)
        {
            //
            System.out.println("Enter your choice:\n"+"1- Create an account\n\n"+
                                               "2- Make deposit\n\n"+
                                               "3- Make withdrawl\n\n"+
                                               "4- Set Zakatable\n\n"+
                                               "5- Partition accounts\n\n"+
                                               "6- Pay zakat\n\n"+
                                               "7- Print all accounts\n\n"+
                                               "8- Exit"
                           ); 
            done=false;
            while(!done)
               {
             	  try
                     {
                       number=Integer.parseInt(reader.readLine());
                       done=true;
                     }
                  catch(NumberFormatException n)
                     {
                    	System.out.println("Wrong input");
                     }
               }
            if(number==1)
               {
               	  System.out.println("Enter account number");
                  int n=0;
                  done=false;
                  while(!done)
                     {  
                         try
                         {
                          n=Integer.parseInt(reader.readLine());
                          done=true;
                         }
                         catch(NumberFormatException e)
                         {
                  	      System.out.println("Wrong input");
                         }
                     } 
                  System.out.println("Enter customer name");
                  String name=reader.readLine();
                  System.out.println("Enter the balance in your account");
                  done=false;
                  double balance=0;
                  while(!done)
                      {
                      	try
                          {
                           balance=Double.parseDouble(reader.readLine());
                           done=true;
                          }
                        catch(NumberFormatException e)
                          {
                           System.out.println("Wrong input");
                          }
                      }
                  BankAccount account=new BankAccount(n,name,balance);
                  container.insert(account);
               }
           if(number==2)
               {
               	  System.out.println("Enter account number");
                  int num=0;
                  try
                    { 
                        num=Integer.parseInt(reader.readLine());
                    }
                  catch(NumberFormatException e)
                     {  
                        System.out.println("Wrong input");
                     }
                  BankAccount account=new BankAccount(num);
                  Enumeration enu=container.getEnumeration();
                  while(enu.hasMoreElements())
                        {
                        	BankAccount test=(BankAccount)enu.nextElement();
                        	if(test.isEQ(account))
                        	    {
                        	    	System.out.println("Enter the amount to be deposited");
                                    double amount=0;
                                    try
                                        {
                                        	amount=Double.parseDouble(reader.readLine());
                                        }
                                    catch(NumberFormatException e)
                                        {
                                        	System.out.println("Wrong input");
                                        }
                                    account.withDraw(amount);
                                }
                        }
                                       
               }
           if(number==3)
               {
               	  System.out.println("Enter account number");
                  int num=Integer.parseInt(reader.readLine());
                  BankAccount nAccount=new BankAccount(num);
                  System.out.println("Enter account number");
                  double amount=Double.parseDouble(reader.readLine());
                  Enumeration enu=container.getEnumeration();
                  while(enu.hasMoreElements())
                    {    
                        BankAccount account=(BankAccount)enu.nextElement();
                        if(account.isEQ(nAccount))
                             nAccount.withDraw(amount);
                    }
               }
           if(number==4)
               {
              	 System.out.println("Enter an account number");
                 int num=Integer.parseInt(reader.readLine());
                 BankAccount account=new BankAccount(num);
                 done=false;
                 Enumeration enu=container.getEnumeration();
                 while(enu.hasMoreElements())
                   {
                   	  BankAccount q=(BankAccount)enu.nextElement();
                      if(q.isEQ(account))
                           {
                           		while(!done)
                            		{
                            			System.out.println("Do you want to make your account zakatable?T/F");
                            			String r=reader.readLine();
                             			if((!r.equalsIgnoreCase("T"))&&(!r.equalsIgnoreCase("F")))
                                   		      System.out.println("Wrong input");
                             			else if(r.equalsIgnoreCase("T"))
                                  			 { 
                                  			 	account.setZakatable(true);
                                     			done=true;
                                   			 }
                             			else if(r.equalsIgnoreCase("F"))
                                             {
                                    	      account.setZakatable(false);
                                              done=true;
                                             }
                                    }
                          }
                   }
              }
          if(number==5)
              {
              	   PartitionVisitor visitor=new PartitionVisitor();
                   PrintingVisitor visitor2=new PrintingVisitor();
                   Enumeration go=container.getEnumeration();
                   while(go.hasMoreElements())
                          visitor.visit(go.nextElement());
                   MyContainer zk1=visitor.getZakatable();
                   MyContainer zk2=visitor.getUnzakatable();
                   Enumeration m1=zk1.getEnumeration();
                   Enumeration m2=zk2.getEnumeration();
                   while(m1.hasMoreElements())
                         visitor2.visit(m1.nextElement());
                   while(m2.hasMoreElements())
                         visitor2.visit(m2.nextElement());
              }
          if(number==6)
              {
              	  PrintingVisitor visitor=new PrintingVisitor();
              	  ZakatVisitor visitor2=new ZakatVisitor();
              	  Enumeration enu=container.getEnumeration();
              	  Enumeration enu2=container.getEnumeration();
                  while(enu.hasMoreElements())
              	      visitor2.visit(enu.nextElement());
              	  while(enu2.hasMoreElements())
              	      visitor.visit(enu2.nextElement());   
              }
          if(number==7)
              { 
                  PrintingVisitor visitor=new PrintingVisitor();
              	  Enumeration enu=container.getEnumeration();
              	  while(enu.hasMoreElements())
              	       {visitor.visit(enu.nextElement());
              	       }
              }
         if(number==8)
              {
              	finish=true;
              }
        } 
         
    }
} 
 
 
