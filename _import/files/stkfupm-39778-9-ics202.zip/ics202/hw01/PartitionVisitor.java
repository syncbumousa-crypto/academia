package ics202.hw01;

import ics202.*;
import ics202.lab01.*;

class PartitionVisitor extends AbstractVisitor
{private MyContainer zakatable;
 private MyContainer unzakatable;
 public void visit(Object obj)
        {
           boolean find;
           BankAccount arg=(BankAccount)obj;
           find = arg.isZakatable();
               if(find)
                  zakatable.insert(arg);
               else
                  unzakatable.insert(arg);
        }
 public MyContainer getZakatable()
        {
       	   return zakatable;
        }
 public MyContainer getUnzakatable()
        {
       	   return unzakatable;
        }
}
