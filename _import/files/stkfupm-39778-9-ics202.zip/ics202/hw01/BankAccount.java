package ics202.hw01;

import ics202.lab01.*;
import ics202.*;

import java.io.*;

class BankAccount extends AbstractObject
{
	private int accountNumber;
    private String customerName;
    private double balance;
    private boolean zakatable;
 
    public BankAccount(int accountNumber,String customerName,double balance)
            {
            	this.accountNumber=accountNumber;
                this.customerName=customerName;
                this.balance=balance;
                this.zakatable=false;
            }
    public BankAccount(int accountNumber)
            {
            	this(accountNumber,null,0.0);
                this.zakatable=false;
            }
    public double getBalance()
            {
            	return balance;
            }
    public boolean isZakatable()
            {
            	return zakatable;
            }
    public void setZakatable(boolean status)
            {
            	zakatable=status;
            }
    public void deposit(double amount)
            {
            	balance+=amount;
            }
    public void withDraw(double amount)
            {
            	if(amount<=balance)
                   balance-=amount;
            }
    public String getStatus()
            {
            	if(zakatable==false)
                   return "Unzakatable";
                else 
                   return "Zakatable";
            }
    public String toString()
            {
            	return accountNumber+"\t"+customerName+"\t"+balance+"\t"+getStatus();
            }
    public int compareTo(MyComparable obj)
            {
            	BankAccount arg=(BankAccount)obj;
                if(accountNumber>arg.accountNumber)
                    return 1;
                else if(accountNumber <arg.accountNumber)
                    return -1;
                else
                    return 0;
            }

}
