package ics202.hw01;

import ics202.*;
import ics202.lab01.*;

class ZakatVisitor extends AbstractVisitor
{
	public void visit(Object obj)
       {BankAccount account;
        if(obj instanceof BankAccount)
              { account=(BankAccount)obj;
                if(account.isZakatable()&&account.getBalance()>=4000.0)
                      account.withDraw(0.025*account.getBalance());
              }
       }
}
