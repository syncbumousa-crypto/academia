package ics202.hw02;

import ics202.*;

public interface TwoWayEnumeration extends Enumeration
{
	boolean hasMorePreviousElements();
	Object  previousElement();
}