package ics202.hw02;------------------------------------------------------------------------------------------------------------package ics202.hw02;

import ics202.*;
import ics202.lab01.*;

public class DoublyLinkedList
{
	protected Element head;
	protected Element tail;
	
	public final class Element
	{
		Object datum;
		Element next;
		Element previous;
		Element(Object datum,Element next,Element previous)
		    {
		    	this.datum=datum;
		    	this.next=next;
		    	this.previous=previous;
		    }
		public Object getDatum()
		    {
		    	return datum;
		    }
		public Element getNext()
		    {
		       return next;
		    }
		public Element getPrevious()
		    {
		       return previous;
		    }
	    public void insertBefore(Object item)
	        {
	        	previous=new Element(item,this,previous);
	        	if(head==this)
	        	     head=previous;
	        }
	    public void insertAfter(Object item)
	        {
	        	next=new Element(item,next,this);
	        	if(tail==this)
	        	    tail=next;
	        }
	        	
	    public void extract()
	        {
	        	Element element=null;
	        	if(this==head)
	        	     head=next;
	        	else
	        	    {
	        	    	element=head;
	        	    	while(element!=null&&element.next!=this)
	        	    	     element=element.next;
	        	    	if(element==null)
	        	    	    throw new InvalidOperationException();
	        	    	else
	        	    	    element.next=next;
	        	    	if(this==tail)
	        	    	    tail=element;
	        	    }
	        }
	}
	
	public Element getHead()
	        {
	        	return head;
	        }
	public Element getTail()
	        {
	        	return tail;
	        }
	public boolean isEmpty()
	        {
	        	return head==null;
	        }
	public Object getFirst()throws ListEmptyException
	       { 
	            if(head==null)
	                  throw new ListEmptyException();
	            return head.datum;
	       }
	public Object getLast()throws ListEmptyException
	       {
	       	    if(head==null)
	       	          throw new ListEmptyException();
	       	    return tail.datum;
	       }
	public void purge()
	       {
	      	    head=null;
	      	    tail=null;
	       }    
	public void prepend(Object obj)
	       {
	       	    Element tmp=new Element(obj,head,null);
	       	    if(head!=null)
	       	         {
	       	         	 tmp.next.previous=tmp;
	       	             head=tmp;
	       	         }
	       	    else
	       	         {
	       	         	head=tmp;
	       	         	tail=tmp;
	       	         }
	       }
	 public void append(Object obj)
	      {
	      	    Element tmp=new Element(obj,null,tail);
	      	    if(head!=null)
	      	         {
	      	         	tail.next=tmp;
	      	            tail=tmp;
	      	         }
	      	    else
	      	         {
	      	         	tail=tmp;
	      	         	head=tmp;
	      	         }
	      }
	 public void assign(DoublyLinkedList list)
	      {
	      	    if(list!=this)
	      	        {
	      	            purge();
	      	            for(Element tmp=list.head;tmp!=null;tmp=tmp.next)
	      	                  append(tmp.datum);
	      	        }
    	  }
     public void extract(Object obj)
         {
         	Element ptr=head;
         	while(ptr!=null&&ptr.datum!=obj)
         	     ptr=ptr.next;
         	if(ptr==null)
                  throw new IllegalArgumentException("Item not found");
            if(ptr==head)
                  head=ptr.next;
            else if(ptr==tail)
                  tail=ptr.previous;
            else
                  ptr.previous.next=ptr.next;
         }  
     public Element find(Object obj)
         {
         	for(Element element=head;element!=null;element=element.next)
         	    {
         	    	if(element.datum.equals(obj))
         	    	      return element;
         	    }
         	return null;
         }
}
	      	        
	      	        
	      	     
	      	    
	       	    
	       	    
	            