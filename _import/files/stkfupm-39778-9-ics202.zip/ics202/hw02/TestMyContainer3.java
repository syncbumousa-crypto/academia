package ics202.hw02;

import ics202.*;
import ics202.lab01.PrintingVisitor;

public class TestMyContainer3
{public static void main(String[] args)
     {
       MyContainer3 c3=new MyContainer3();
       c3.insert(new Int(1));
       c3.insert(new Int(2));
       c3.insert(new Int(3));
       c3.insert(new Int(4));
       c3.insert(new Int(5));
       c3.insert(new Int(6));
       c3.insert(new Int(7));
       c3.insert(new Int(8));
       c3.insert(new Int(9));
       c3.insert(new Int(10));
       TwoWayEnumeration enu=(TwoWayEnumeration)c3.getEnumeration();
       
       System.out.println("The list is as follows:");
       while(enu.hasMoreElements())
            System.out.println(enu.nextElement());
       System.out.println("The reversed list is as follows:");
       while(enu.hasMorePreviousElements())
             System.out.println(enu.previousElement());
             
     }
}
       
       
       
     	