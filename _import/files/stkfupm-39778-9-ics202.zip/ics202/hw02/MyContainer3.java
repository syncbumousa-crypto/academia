package ics202.hw02;

import ics202.*;

public class MyContainer3 extends AbstractContainer 
{
	protected DoublyLinkedList dlist=new DoublyLinkedList();
	
	public boolean isFull()
	    {
	    	return false;
	    }
	public boolean isEmpty()
	    {
	    	return dlist.isEmpty();
	    }
    public void insert(MyComparable obj)
        {
        	dlist.append(obj);
            ++count;
        }
    public void withdraw(MyComparable obj)
        {
        	dlist.extract(obj);
            --count;
        }
    public void purge()
        {
        	dlist.purge();
            count=0;
        }
    public Enumeration getEnumeration()
        {
        	return new TwoWayEnumeration()
        	   {
        	   	  private DoublyLinkedList.Element element=dlist.getHead(); 
        	      private boolean moreNextElements=true;
        	      private boolean morePreviousElements=false;
        	      
        	      public boolean hasMorePreviousElements()
        	   	       {
        	   	       	 return morePreviousElements==true;  
        	   	       }
        	   	   public boolean hasMoreElements()
        	   	       {
        	   	       	 return moreNextElements==true;  
        	   	       }
        	   	   public Object nextElement()
        	   	       {
        	   	       	   Object obj=element.getDatum();
        	   	       	   if(element.getNext()==null)
        	   	       	        moreNextElements=false;
        	   	       	   else
        	   	       	        {
        	   	       	         element=element.getNext();
        	   	       	         morePreviousElements=true;
        	   	       	        }
        	   	       	   return obj;
        	   	       }
        	   	   public Object previousElement()
        	   	       {
        	   	           Object obj=element.getDatum();
        	   	           if(element.getPrevious()==null)
        	   	                morePreviousElements=false;
        	   	           else
        	   	                {
        	   	                 element=element.getPrevious();
        	   	                 moreNextElements=true;
        	   	                }
        	   	           return obj;
        	   	       }
               };
         }
     public int compareTo(MyComparable obj)
         {
         	throw new MethodNotImplemented();
         }
}
        	   	     
        	   	       	           