package ics202.hw02;

import ics202.*;
import java.io.*;
import java.util.StringTokenizer;

public class TextEditor
{
 static BufferedReader console=new BufferedReader(new InputStreamReader(System.in));
 public static void main(String[] args)throws IOException
    {
    	DoublyLinkedList dlist=new DoublyLinkedList();
        boolean done=false;
        int count=0;
        String s;
        StringTokenizer tk1;
        int choice=0;
        do
          {
          	showMenu();
          	choice=getChoice();
          	switch(choice)
          	     {
          	     	case 1:
          	     	        boolean done1=false;
          	     	        System.out.println("Type text, may be more than one line.Type Q and hit enter to stop");
          	     	        while(!done1)
          	     	        { 
          	     	            s=console.readLine();
          	     	            if(s.equalsIgnoreCase("Q"))
          	     	            done1=true;
          	     	        else
          	     	           {
          	     	           	  Str s1=new Str(s);
          	     	           	  Association association=new Association(s1,new Int(count++));
          	     	           	  dlist.append(association);
          	     	           }
          	     	        }
          	     	        break;
          	        case 2:
          	               int i=0;
          	               do
          	                 {
          	                 	System.out.println("Enter the line number at which you want to insert:");
          	                 	i=Integer.parseInt(console.readLine());
          	                 }
          	               while(i<0&&i>count);
          	               System.out.println("Enter the text");
          	               Str s1=new Str(console.readLine());
          	               DoublyLinkedList.Element tail=dlist.getTail();
          	               Association association1=new Association(s1,new Int(i));
          	               DoublyLinkedList.Element element=findElement(new Int(i),dlist);
          	               boolean done3=false;
          	               if(element!=null)
          	                   {
          	                   	   element.insertBefore(association1); 	 
                                   for(DoublyLinkedList.Element e=element;e!=null&&!done3;e=e.getNext())
                                        {
                                        	if(e==tail)
                                        	   {
                                        	   	   Association change1=(Association)e.getDatum();
                                        	   	   dlist.extract(change1);
                                        	   	   change1=new Association(change1.getKey(),new Int(++i));
                                        	   	   dlist.append(change1);
                                        	   	   done3=true;;
                                               }
                                        	else
                                        	   {
                                        	       Association change2=(Association)e.getDatum();
                                        	       dlist.extract(change2);
                                                   change2=new Association(change2.getKey(),new Int(++i));
                                                   dlist.append(change2);
                                               }                    
                                        }
                               }   
                          break;
                   case 3:
                          print(dlist);
                          break;
                   case 4:
                          done=true;
                          break;
              }
        }
    while(choice>0&&choice<5&&!done);
   }
public static void showMenu()
    {
    	System.out.print("***************************\n*   A Simple Line "+
    	                 "Editor   *\n***************************\n"+
    	                 "1- Type Mode\n"+
    	                 "2- Insert Mode\n"+
    	                 "3- Print All Lines\n"+
    	                 "4- Quit"
    	                );
    }
    	                 
 public static int getChoice()throws IOException
    {
    	int choice; 
        do {
             System.out.print("\nYour choice? : ");
             choice = Integer.parseInt(console.readLine());
		   } 
        while (choice < 1 || choice > 4);    
        return choice;
    }
 
 public static DoublyLinkedList.Element findElement(Object obj,DoublyLinkedList list)
    {
    	for(DoublyLinkedList.Element g=list.getHead();g!=null;g=g.getNext())
    	    {
    	        Association association1=(Association)g.getDatum();
    	        if(association1.getValue().equals(obj))
    	              return g;
    	    }
    	return null;
    }
 
 public static void print(DoublyLinkedList list)
    {
    	for(DoublyLinkedList.Element e=list.getHead();e!=null;e=e.getNext())
    	      {
    	      	  Association c=(Association)e.getDatum();
    	      	  System.out.println((Int)c.getValue()+"> "+(Str)c.getKey());
    	      }
    }
}	   	                    