package ics202.lab03;

import ics202.*;
import java.io.*;

public class TestMyLinkedList {
	static	BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

	public static void main (String[] args) throws IOException {
		MyLinkedList list = new MyLinkedList();
		int choice;
		Int datum;
		
		do {
			showMenu();
			choice = getChoice();
			
			switch (choice) {
				case 1 : // prepend
						System.out.print("Enter the element to prepend: ");
						list.prepend(new Int(Integer.parseInt(stdin.readLine())));
						System.out.println("\n"+list);
						break;
				case 2 :// append  
			            System.out.print("Enter the element to append: ");
			            list.prepend(new Int(Integer.parseInt(stdin.readLine())));
			            System.out.println("\n"+list);
			            break;
				case 3 :// insert before
				        System.out.println("Enter the element to be inserted");
				        Int n1=new Int(Integer.parseint(stdin.readLine());
				        System.out.println("Which element do you wish to put it in front of");
				        Int n2=new Int(Integer.parseInt(stdin.readLine());
				        if(list.find(n2)
				             n2.insertBefore(n1);
				        break;
				case 4 :// insert after
				        System.out.println("Enter the element to be inserted");
				        Int n1=new Int(Integer.parseint(stdin.readLine());
				        System.out.println("Which element do you wish to put it after");
				        Int n2=new Int(Integer.parseInt(stdin.readLine());
				        if(list.find(n2)
				             n2.insertBefore(n1);
				        break;
				case 5 :// get first  
				case 6 :// get last
				case 7 :// remove first
				case 8 :// remove last
				case 9 :// remove element
			}
			
		} while (choice != 10);
	}
    
	static int getChoice() throws IOException{
      int choice; 
      do {
         System.out.print("\nYour choice? : ");
         choice = Integer.parseInt(stdin.readLine());
		} while (choice < 1 || choice > 10);    
      return choice;
	}
	
	static void showMenu() {
 		System.out.println("\n***************************");
 		System.out.println("*   Testing Linked List  *");
 		System.out.println("***************************\n");
 		System.out.println("1.  Prepend an element");
 		System.out.println("2.  Append an element");
 		System.out.println("3.  Insert before an element");
 		System.out.println("4.  Insert after an element");
 		System.out.println("5.  Get first element");
 		System.out.println("6.  Get last element");
		System.out.println("7.  Remove first element");
		System.out.println("8.  Remove last element");
		System.out.println("9.  Remove an element");
 		System.out.println("10. Quit");
 	}
}
