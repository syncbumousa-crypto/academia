package ics202.hw05;

import  ics202.*;
import java.io.*;
import java.util.*;

public class DigraphAsMatrixTest 
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader in = new BufferedReader(new FileReader("GB.txt"));
		int size = Integer.parseInt(in.readLine());
        DigraphAsMatrix graph = new DigraphAsMatrix(size);
		for (int i=0; i<size; i++)
			graph.addVertex(i);
		int v0, v1, weight;
		String edge;
		while ((edge = in.readLine()) != null) 
		{	
			StringTokenizer tokenizer = new StringTokenizer(edge, " ,");
			v0 = Integer.parseInt(tokenizer.nextToken());
			v1 = Integer.parseInt(tokenizer.nextToken());
			if (tokenizer.hasMoreTokens())
			{
				weight = Integer.parseInt(tokenizer.nextToken());
				graph.addEdge(v0, v1, new Int(weight));
			}
			else
				graph.addEdge(v0, v1);
		}
		System.out.println(graph);
		System.out.println("Depth First Traversal - PreOrder:");
		graph.depthFirstTraversal(new PreOrder(new PrintingVisitor()), 0);
		System.out.println();
		System.out.println("Breadth First Traversal:");
		graph.breadthFirstTraversal(new PrintingVisitor(), 0);
	}
}

