package ics202;

public class DigraphAsLists extends GraphAsLists implements Digraph
{
    public DigraphAsLists(int size) {
        super(size);
    }
}
