package ics202;

public class DigraphAsMatrix extends GraphAsMatrix implements Digraph
{
	public DigraphAsMatrix(int size)
	{
		super(size);
    }
    public boolean isStronglyConnected()
    {
        CountingVisitor visitor=new CountingVisitor();
        depthFirstTraversal(new PreOrder(visitor),0);
        if(visitor.getCount()==numberOfVertices)
             return true;
        else
             return false;	
    }
    public void topologicalOrderTraversal(Visitor visitor)
    {
         int[] inDegree=new int[numberOfVertices];
         for(int v=0;v<numberOfVertices;v++)
               inDegree[v]=0;
         Enumeration p=getEdges();
         while(p.hasMoreElements())
              {
              	 Edge edge=(Edge)p.nextElement();
              	 Vertex to=edge.getV1();
              	 ++inDegree[to.getNumber()];
              }
         Queue queue=new QueueAsLinkedList();
         for(int v=0;v<numberOfVertices;v++)
              {
              	  if(inDegree[v]==0)
              	       queue.enqueue(vertex[v]);
              	  while(!queue.isEmpty() && !visitor.isDone())
              	       {
              	       	   Vertex vertex=(Vertex)queue.dequeue();
              	       	   visitor.visit(vertex);
              	       	   Enumeration q=vertex.getSuccessors();
              	       	   while(q.hasMoreElements())
              	       	        {
              	       	        	Vertex to=(Vertex)q.nextElement();
              	       	        	if(--inDegree[to.getNumber()]==0)
              	       	        	     queue.enqueue(to);
              	       	        }
              	       }
              }
    }
}