package ics202.lab08;


import java.io.*;
import java.util.StringTokenizer;
import ics202.*;

public class CrossReferenceGenerator
{
	static BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
	
	public static void main(String[] args) throws IOException
	{
		AVLTree avltree = null;
		int choice;
		
		do 
		{
			showMenu();
			
			choice = getChoice();
			switch (choice) 
			{
				case 1:	avltree = createCrossReference();
						System.out.println("CROSS-REFERENCE HAS BEEN CREATED");
						break;
				case 2: if(avltree == null)
				          System.out.println("ERROR - The cross-reference has not been created");
				        else
				          displayCrossReference(avltree);
				
						break;
				case 3: if(avltree == null)
				          System.out.println("ERROR - The cross-reference has not been created");
				        else
				        {
				          System.out.print("Enter the word to search for: ");
    					  Str word = new Str((stdin.readLine().trim()).toLowerCase());
				          searchWord(word, avltree);
				        }
						break;
			}
			
		} while (choice != 4);
	}
	
	public static AVLTree createCrossReference() throws IOException
	{
		BufferedReader  inputStream = null;
		
		System.out.println("Enter the full path to the text file: ");
		
		String path = stdin.readLine().trim();
		
		try
		{
			inputStream = new BufferedReader(new FileReader(path));
		 
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Error - File " +  path + " not found");
			System.exit(1);
		}

		
		AVLTree avltree = new AVLTree();
		
		Str word;
		
		String inputLine = null;
		
		int lineNumber = 0;
		
		while((inputLine= inputStream.readLine()) != null)
		{
			lineNumber++;
			StringTokenizer tokenizer = new StringTokenizer(inputLine, " .,;!:");
			while(tokenizer.hasMoreElements())
			{
			  word = new Str((tokenizer.nextToken()).toLowerCase());
			  // To be completed by students
	          MyAssociation associate=new MyAssociation(word);
	          MyComparable find=avltree.find(associate);
			  if(find!=null)
			       {
			           MyAssociation assoc=(MyAssociation)find;
			           int newLine=assoc.getLastLineNumber();
			           if(newLine!=lineNumber)
			                 assoc.prependLineNumber(lineNumber);
			           assoc.incrementWordCount();
			           
			       }
			  else
			       {
			       	   associate.prependLineNumber(lineNumber);
			       	   avltree.insert(associate);
			       }
			}
		}
		
		inputStream.close();
		return avltree;
	}
	
	public static void displayCrossReference(AVLTree avltree)
    {
		// Displays avltree in increasing order of keys.
		// To be completed by students
		avltree.depthFirstTraversal(new PreOrder(new PrintingVisitor()));
		

    }
    
    public static void searchWord(Str word, AVLTree avltree)
    {
		/* Searches for word in avltree and displays the corresponding avltree node
		   if the word is found.
		To be completed by students */
		if(avltree.isEmpty())
		      System.out.println("Object not found");
		MyAssociation mCom=(MyAssociation)avltree.getKey();
		if(mCom.getKey().isEQ(word))
		         System.out.println(mCom);
		else if(mCom.getKey().isLT(word))
		         searchWord(word,avltree.getRight());
		else
		         searchWord(word,avltree.getLeft());   
		
    }
    
    public static int getChoice() throws IOException
    {
      int choice; 
      do 
      {
         System.out.print("\rYour choice? : ");
         choice = Integer.parseInt(stdin.readLine());
         if(choice < 1 || choice > 4)
           System.out.println("ERROR - Choose 1, 2, 3, or 4");
	  } while (choice < 1 || choice > 4);    
      return choice;
	}
	
	public static void showMenu() 
	{
 		System.out.println("\n********************************");
 		System.out.println("*   Cross-reference Generator  *");
 		System.out.println("********************************");
 		System.out.println("1.  Create a cross reference for a text file");
 		System.out.println("2.  Display the cross reference");
 		System.out.println("3.  Search for a word in the cross reference");
		System.out.println("4.  Quit");
 	}  
}