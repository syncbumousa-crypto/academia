package ics202.lab08;

import java.io.*;
import ics202.*;

public class BinarySearchTreeTest2
{
	public static void main(String[] args) throws IOException
	{
		
	  int choice;
	  
	  do 
	  {
		
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		
		BinarySearchTree mytree = new BinarySearchTree();
		
		int count = 1;
		String inputLine = null;
		System.out.println("To create a Binary Search Tree:");
		System.out.print("Enter key#"+ count+ ": ");
			
		while(! (inputLine = stdin.readLine()).equals(""))
		{
			
			try
			{
			   int key = Integer.parseInt(inputLine);
			   mytree.insert(new Int(key));
			   count++;
			   System.out.print("Enter key#"+ count+ " or press Enter to Quit: ");
			}
			
			catch(IllegalArgumentException e)
			{
				System.out.println("Error - " +  e);
				System.out.print("Enter key#"+ count+ " or press Enter to Quit: ");
				continue;
			}
		}

		System.out.println("\nThe height of the BST is: " + mytree.getHeight());

		Visitor v = new PrintingVisitor();
		
		System.out.print("\nPreorder traversal:      ");
		mytree.depthFirstTraversal(new PreOrder(v));
		
		System.out.print("\nInorder traversal:       ");
		mytree.depthFirstTraversal(new InOrder(v));
		
		System.out.print("\nPostorder traversal:     ");
		mytree.depthFirstTraversal(new PostOrder(v));
		
		System.out.print("\nBreadth first traversal: ");
		mytree.breadthFirstTraversal(v);
		System.out.println("\nEnter 1 to Quit, Any other number to process another BST");
		choice = Integer.parseInt(stdin.readLine().trim());
	}while(choice != 1);
  }
}