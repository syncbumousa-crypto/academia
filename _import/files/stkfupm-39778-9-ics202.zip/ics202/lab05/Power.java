package ics202.lab05;

import java.io.*;

public class Power
{
	public static void main(String[] args)  throws IOException
	{
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		int n;
		double x;


			
		System.out.print("Enter a double value : ");
		x = Double.parseDouble(stdin.readLine().trim());
		
		do
		{
			System.out.print("Enter a positive integer for the power : ");
			n = Integer.parseInt(stdin.readLine().trim());
		}while(n < 0);
			
			Power p = new Power();
		double value=p.getPower(x,n);// the call to be implemented by students
		
		System.out.println(x + " raised to power " + n + " = " + value);
	}
public static double getPower(double n,int r) {
	
	return power(n,r,1);

}
	public static double power(double q,int r, double m) {
		
	  if(r==0)
		return m;	 
		else
		return power(q,r-1,q*m);
		
		//}	else
			//	l=Math.power(q,r);// System.out.println(Math.power(q,r));
		
	
	
	}
	
	// methods to be implemented by students

}