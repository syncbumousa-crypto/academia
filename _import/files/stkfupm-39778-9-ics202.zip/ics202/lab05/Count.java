package ics202.lab05;

import java.io.*;

public class Count
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.print("Enter a string : ");
		String string = stdin.readLine();
		
		System.out.print("Enter a sub-string : ");
		String substring = stdin.readLine();
		
		int count = // the call to be implemented by students
		
		System.out.println(substring + " occurs " + count + " times in " + string);
	}
	
	
	
	// the method to be implemented by students
	
	
	
}