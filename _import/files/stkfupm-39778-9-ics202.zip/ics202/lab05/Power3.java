
package ics202.lab05;

import java.io.*;

public class Power3 {
  public static void main(String[] args)  throws IOException {
		
	BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
	int n;
	int x;
			
	System.out.print("Enter an integer value : ");
	x = Integer.parseInt(stdin.readLine().trim());
	
	do {
		System.out.print("Enter a positive integer for the power : ");
		n = Integer.parseInt(stdin.readLine().trim());
		}while(n < 0);
			
	Power3 p1 = new Power3();
	int value=p1.getPower2(x,n);
		
	System.out.println(x + " raised to power " + n + " = " + value);
	}
    public static int getPower2(int n,int r) {
      if(r==0)
      return 1;
      else
	  return power(n,r,n-1,0);
    }
	public static int power(int q,int r,int y, int m) {
	  int current=0;
	   if(r==0)
	   return m;	 
	   else {
			for(int i=0;i<y;i++) 
               current+=q+m;
         	}
	   return power(current,r-1,y,m+q);
	}
}