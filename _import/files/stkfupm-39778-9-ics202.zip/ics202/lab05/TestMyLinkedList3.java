
package ics202.lab05;


import ics202.*;
import java.io.*;

public class TestMyLinkedList3 
{
	public static void main(String[] args) throws IOException 
	{
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		MyLinkedList3 list = new MyLinkedList3();
		
		int i = 1;
		String inputLine;
		
		System.out.print("Enter datum value#"+ i+ " (or press Enter to quit): ");
		while(!(inputLine = stdin.readLine()).equals(""))
		{
			list.append(new Int(Integer.parseInt(inputLine)));
			System.out.print("Enter datum value#"+ ++i + " (or press Enter to quit): ");
		}
		
		System.out.println("The list is: " + list);
		
		if(! list.isEmpty())
		{

			System.out.print("Enter the datum value to be searched for: ");
			MyLinkedList3.Element element = list.find(new Int(Integer.parseInt(stdin.readLine().trim())));
		
			if(element == null)
		   		System.out.println("NOT FOUND");
			else
		   		System.out.println("FOUND");
		   
			System.out.print("Enter the datum value of the node to insert before: "); 
			element = list.find(new Int(Integer.parseInt(stdin.readLine().trim()))); 
		
			if(element == null)
		   		System.out.println("THERE IS NO NODE WITH THE GIVEN DATUM VALUE");
			else
			{
		   		System.out.print("Enter the datum value to be inserted in the list: "); 
		   		element.insertBefore(new Int(Integer.parseInt(stdin.readLine().trim()))); 
		   
		   		System.out.println("The modified list is: " + list);
			}
	
		System.out.print("Enter datum value to be extracted by the extract() method of MyLinkedList3 class or press Enter to quit : ");
		while(!(inputLine = stdin.readLine()).equals(""))
		{
			list.extract(new Int(Integer.parseInt(inputLine)));
			System.out.print("Enter datum value to be extracted by the extract() method of MyLinkedList3 class or press Enter to quit): ");

		}
		
		System.out.println("The list is: " + list);
	
		System.out.print("Enter datum value to be extracted by the extract() method of MyLinkedList3.Element class or press Enter to quit : ");
			    Int m=new Int(Integer.parseInt(stdin.readLine().trim()));

		while(!(inputLine = stdin.readLine()).equals("")) { 
			element.extract();
			System.out.print("Enter datum value to be extracted by the extract() method of MyLinkedList3.Element class or press Enter to quit : ");

		}
		
		System.out.println("The list is: " + list);
		
	    }
	}
}