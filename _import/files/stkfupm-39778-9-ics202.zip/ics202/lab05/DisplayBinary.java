package ics202.lab05;


import ics202.*;
import java.io.*;

public class DisplayBinary
{
	static StackAsLinkedList stack = new StackAsLinkedList();
	
	
	public static void main(String[] args) throws IOException
	{
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
		
		int value;
		
		do
		{
		  System.out.print("Enter a positive integer: ");
		
		  value = Integer.parseInt(stdin.readLine());
	    }while(value < 0);
		
		displayBinary(value);
	}
	
	public static void displayBinary(int n)
	{int current=n%2;
		int tmp;
		if(n>1)
			displayBinary(n/2);
			else {
			
				int i=1,last=0;// to be implemented by students
	for( ; i<=n;++i)
		 tmp= current;
	current+=last;
	last=tmp;
}
		displayBinary(current);
			}
}