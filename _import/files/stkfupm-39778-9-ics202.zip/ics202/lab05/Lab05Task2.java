class Lab05Task2{
  private int[] oneD = {9, 12, 6, 17, 7};  //you can assign different values to this array to test
	
  public static void main(String args []){
    Lab05Task2 obj = new Lab05Task2();
    System.out.println(obj.hasLessThan(7));
  }
  public boolean hasLessThan(int n){
    //need to call the auxillary method here!
  }
  public boolean hasLessThanAux(int n, int m, boolean ans){
	//to be implemented by students
  }
}
