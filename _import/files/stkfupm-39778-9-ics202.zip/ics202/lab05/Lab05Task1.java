public class Lab05Task1{
	public static void main(String args []){
    	new Lab05Task1().welcomeShabab(3);
  	}
	
	public void welcomeShabab(int n){
		//to be implemented as a recursive method by students
	}
}
