package ics202;

public class CountingVisitor extends AbstractVisitor
{
	protected int count=0;
	public void visit(Object obj)
	    {
	    	count++;
	    }
	public int getCount()
	    {
	    	return count;
	    }
}