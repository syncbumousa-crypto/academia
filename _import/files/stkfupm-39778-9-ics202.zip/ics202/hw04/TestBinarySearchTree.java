package ics202.hw04;
import ics202.*;
import java.io.*;

public class TestBinarySearchTree
{
   static BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
   public static void main(String[] args)throws IOException
     {
     	int choice=0;
     	BinarySearchTree tree=new BinarySearchTree();
     	System.out.println("Enter number of nodes");
     	int n=Integer.parseInt(reader.readLine());
     	for(int i=1;i<=n;i++)
     	   {
     	     System.out.println("Enter node#"+i);
     	     Int num=new Int(Integer.parseInt(reader.readLine()));
     	     tree.insert(num);
     	   }
     	 do{
     	    showMenu();
	        choice=getChoice();
	        switch(choice)
	         {
	         	case 1:
	         	       System.out.println("Depth of which node?");
	         	       Int num=new Int(Integer.parseInt(reader.readLine()));
	         	       int k=tree.depth(num);
	         	       System.out.println("The depth of the node is:"+k);
	         	       printTree(tree);
	         	       break;
	         	 case 2:
	         	       System.out.println("Width of the tree is:"+tree.width());
	         	       printTree(tree);
	         	       break;
	         	case 3:
	         	       if(tree.isFull())
	         	           System.out.println("Yes, it is full");
	         	       else
	         	           System.out.println("No, the tree is not full");
	                   printTree(tree);
	                   break;
	            case 4:
	                   addElement(tree);
	                   printTree(tree);
	                   break;
	            case 5:
	                   deleteElement(tree);
	                   printTree(tree);
	                   break;      
	          }
	        }while(choice!=6);
	  }
	  
	  public static void showMenu()
	  {
        System.out.println("\n********************************");
 		System.out.println("*   Testing Binary Search Tree  *");
 		System.out.println("********************************");
 		System.out.println("1.  Find depth");
 		System.out.println("2.  Find width");
 		System.out.println("3.  Is the tree full?");
 		System.out.println("4.  Add element");
 		System.out.println("5.  Delete element");
 		System.out.println("6.  exit");
      }
      
      public static int getChoice()throws IOException
      {
        int choice; 
        do {
             System.out.print("\rYour choice? : ");
             choice = Integer.parseInt(reader.readLine());
		   } while (choice < 1 || choice > 6);    
      return choice;
      }
      public static void addElement(BinarySearchTree tree)throws IOException
      {
      	 System.out.println("Enter the element to be added");
      	 Int i=new Int(Integer.parseInt(reader.readLine()));
      	 tree.insert(i);
      }
       public static void deleteElement(BinarySearchTree tree)throws IOException
      {
      	 System.out.println("Enter the element to be deleted");
      	 Int i=new Int(Integer.parseInt(reader.readLine()));
      	 tree.withdraw(i);
      }
      public static void printTree(BinarySearchTree tree)
      {
      	tree.accept(new PrintingVisitor());
      }
}