package ics202;

import java.util.NoSuchElementException;

public abstract class AbstractGraph extends AbstractContainer implements Graph {
    protected int numberOfVertices;
    protected int numberOfEdges;
    protected Vertex vertex[];
	
    public AbstractGraph(int size) {
        vertex = new Vertex[size];
    }

    protected final class GraphVertex extends AbstractObject implements Vertex  {
        protected int number;
        protected Object weight;

        public GraphVertex(int v, Object obj) {
            number = v;
            weight = obj;
        }
        
        public GraphVertex(int v) {
            this(v, null);
        }
  
        public int getNumber() {
            return number;
        }

        public Object getWeight() {
            return weight;
        }

        protected int compareTo(MyComparable comparable) {
			//To be implemented by Students
            GraphVertex comp=(GraphVertex)comparable;
            if(number==comp.number)
                 return 0;
            else if(number>comp.number)
                 return 1;
            else
                 return -1;
        }

        public Enumeration getIncidentEdges() {
            return AbstractGraph.this.getIncidentEdges(number);
        }

        public Enumeration getEmanatingEdges() {
            return AbstractGraph.this.getEmanatingEdges(number);
        }

        public Enumeration getPredecessors() {
            return new Enumeration() {
                Enumeration edges = getIncidentEdges();

                public boolean hasMoreElements() {
                    return edges.hasMoreElements();
                }

                public Object nextElement() {
                    Edge edge = (Edge)edges.nextElement();
                    return edge.getMate(GraphVertex.this);
                }
            };
        }

        public Enumeration getSuccessors() {
			//To be implemented by Students
            return new Enumeration(){
            	  Enumeration edges=getEmanatingEdges();
            
            public boolean hasMoreElements() {
            	 return edges.hasMoreElements();
                }
            
            public Object nextElement() {
            	 Edge edge=(Edge)edges.nextElement();
            	 return edge.getMate(GraphVertex.this);
                }
           };
        }
        public String toString() {
            StringBuffer stringbuffer = new StringBuffer();
            stringbuffer.append("Vertex {" + number);
            if(weight != null)
                stringbuffer.append(", weight = " + weight);
            stringbuffer.append("}");
            return stringbuffer.toString();
        }
    }

    protected final class GraphEdge extends AbstractObject implements Edge {
        protected int v0;
        protected int v1;
        protected Object weight;

        public GraphEdge(int v, int w, Object obj) {
            v0 = v;
            v1 = w;
            weight = obj;
        }

        public GraphEdge(int v, int w) {
            this(v, w, null);
        }

        public Vertex getV0() {
            return vertex[v0];
        }

        public Vertex getV1() {
            return vertex[v1];
        }

        public Object getWeight() {
            return weight;
        }

        public Vertex getMate(Vertex v) {
            if(v.getNumber() == v0)
                return vertex[v1];
            if(v.getNumber() == v1)
                return vertex[v0];
            else
                throw new InvalidOperationException("invalid vertex");
        }

        public boolean isDirected() {
            return AbstractGraph.this.isDirected();
        }

        protected int compareTo(MyComparable comparable) {
			//To be implemented by Students
            GraphEdge comp=(GraphEdge)comparable;
            if(v0==comp.v0)
                 {
                 	if(v1==comp.v1)
                 	     return 0;
                 	else if(v1>comp.v1)
                 	     return 1;
                 	else
                 	     return -1;
                 }
            else if(v0<comp.v0)
                 return -1;
            else
                 return 1;
        }

        public String toString() {
            StringBuffer stringbuffer = new StringBuffer();
            stringbuffer.append("Edge {" + v0);
            if(isDirected())
                stringbuffer.append("->" + v1);
            else
                stringbuffer.append("--" + v1);
            if(weight != null)
                stringbuffer.append(", weight = " + weight);
            stringbuffer.append("}");
            return stringbuffer.toString();
        }
    }

 // These are methods of AbstractGraph
    public int getNumberOfVertices() {
        return numberOfVertices;
    }

    public int getNumberOfEdges() {
        return numberOfEdges;
    }

    public void purge() {
        for(int v = 0; v < numberOfVertices; v++)
            vertex[v] = null;

        numberOfVertices = 0;
        numberOfEdges = 0;
    }

    protected void addVertex(Vertex v) {
			//To be implemented by Students
       if(numberOfVertices==vertex.length)
           throw new ContainerFullException();
       if(v.getNumber()!=numberOfVertices)
           throw new InvalidOperationException();
       vertex[numberOfVertices++]=v;
    }

    public final void addVertex(int v, Object obj) {
        addVertex(new GraphVertex(v, obj));
    }

    public final void addVertex(int v) {
        addVertex(v, null);
    }

    public Vertex getVertex(int v) {
       if(v < 0 || v > numberOfVertices - 1)
            throw new IndexOutOfBoundsException();
       return vertex[v];
    }

    public Enumeration getVertices()  {
        return new Enumeration() {
           protected int v;

           public boolean hasMoreElements() {
                return v < numberOfVertices;
            }

            public Object nextElement()   {
                if(v >= numberOfVertices)
                    throw new NoSuchElementException();
                else
                    return vertex[v++];
            }
        };
    }

    public boolean isDirected() {
        return this instanceof Digraph;
    }

    public final void addEdge(int v, int w, Object obj)  {
        addEdge(new GraphEdge(v, w, obj));
    }

    public final void addEdge(int v, int w) {
        addEdge(v, w, null);
    }

    public void depthFirstTraversal(PrePostVisitor visitor, int start) {
        boolean visited[] = new boolean[numberOfVertices];
        for(int v = 0; v < numberOfVertices; v++)
            visited[v] = false;

        depthFirstTraversal(visitor, vertex[start], visited);
    }

    private void depthFirstTraversal(PrePostVisitor visitor, Vertex v, boolean[] visited){
        if(visitor.isDone())
            return;
        visitor.preVisit(v);
        visited[v.getNumber()] = true;
        
        Enumeration p = v.getSuccessors();
        while(p.hasMoreElements())    {
            Vertex to = (Vertex) p.nextElement();
            if(! visited[to.getNumber()])
                depthFirstTraversal(visitor, to, visited);
        }
        visitor.postVisit(v);
    }

    public void breadthFirstTraversal(Visitor visitor, int start)  {
        boolean enqueued[] = new boolean[numberOfVertices];
        for(int v = 0; v < numberOfVertices; v++)
            enqueued[v] = false;

        Queue queue = new QueueAsLinkedList();
        enqueued[start] = true;
        queue.enqueue(vertex[start]);
        
        while(!queue.isEmpty() && !visitor.isDone())  {
            Vertex v = (Vertex) queue.dequeue();
            visitor.visit(v);
            Enumeration p = v.getSuccessors();
            
            while(p.hasMoreElements()) {
                Vertex to = (Vertex) p.nextElement();
                if(!enqueued[to.getNumber()]) {
                    enqueued[to.getNumber()] = true;
                    queue.enqueue(to);
                }
            }

        }
    }

    public Enumeration getEnumeration()  {
        return getVertices();
    }

    public String toString()  {
        final StringBuffer buffer = new StringBuffer();
        Visitor visitor = new AbstractVisitor() {
            public void visit(Object obj) {
                Vertex v = (Vertex) obj;
                buffer.append(v + "\n");
                Edge edge;
                
                Enumeration p = v.getEmanatingEdges(); 
                while (p.hasMoreElements()) {
                    edge = (Edge) p.nextElement();
                	buffer.append("    " + edge + "\n");
				}
            }

        };
        accept(visitor);
        return "{" + buffer + "}";
    }

    public void topologicalOrderTraversal(Visitor visitor)  {
		throw new MethodNotImplemented();
    }

    public boolean isConnected() {
		throw new MethodNotImplemented();
    }

    public boolean isStronglyConnected() {
		throw new MethodNotImplemented();
    }

    public boolean isCyclic()  {
		throw new MethodNotImplemented();
    }

    protected abstract Enumeration getIncidentEdges(int i);
    protected abstract Enumeration getEmanatingEdges(int i);
    protected abstract void addEdge(Edge edge);
    public abstract Edge getEdge(int i, int j);
    public abstract boolean isEdge(int i, int j);
    public abstract Enumeration getEdges();
}
