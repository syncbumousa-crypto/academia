package ics202.lab04;

import ics202.*;
import java.util.StringTokenizer;

public class PostFixNotation
{
	public static void main(Sring[] args)
	    {
	       String s1="5 9 + 2 * 6 5 * +";
	       String s2="6 2 + 5 8 4 / - +";
	       String s3="6 2 + 5 * 8 4 / -";
	       evaluate(s1);
	       evalute(s2);
	       evaluate(s3);
	    }
	 
	 public static void evalute(String s)
	   {
	   	  StackAsLinkedList llist=new StackAsLinkedList();
	   	  StringTokenizer tk1=new StringTokenizer(s);
	   	  while(tk1.hasMoreTokens())
	   	       {
	   	       	  String s=tk1.nextToken();
	   	       	  boolean operator=isOperator(s);
	   	       	  boolean digit1=isDigit(s);
	   	       	  if(digit1==true)
	   	       	      llist.push(new Int(Integer.parseInt(s)));
	   	       	  else if(operator==true)
	   	       	     {
	   	       	     	int result=0;
	   	       	     	Int op1=(Int)llist.pop()throws ContainerEmptyException;
	   	       	     	Int op2=(Int)llist.pop()throws ContainerEmptyException;
	   	       	     	char ch=s.charAt(0);
	   	       	     	switch(ch)
	   	       	     	{
	   	       	     		case '+':
	   	       	     		         result=op1.intValue()+op2.intValue();
	   	       	     		         break;
	   	       	     		case '*':
	   	       	     		         result=op1.intValue()*op2.intValue();
	   	       	     		         break;
	   	       	     	
	   	       	            case '/':
	   	       	                     result=op1/op2;
	   	       	                     break;
	   	       	            case '-':
	   	       	                     result=op1-op2;
	   	       	                     break;
	   	       	         }
	   	       	         llist.push(new Int(result));
	   	       	     }
	   	       }
	   }
	   
	   public static boolean isOperator(String s)
	       {
	       	return s.equals("*")||
	               s.equals("+")||
	               s.equals("-")||
	               s.equals("/");
	       }
	   public static boolean isDigit(String s)             	
	        {
	                  	
	   	  