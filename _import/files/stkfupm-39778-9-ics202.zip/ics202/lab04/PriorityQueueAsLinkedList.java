package ics202.lab04;

import ics202.*; 
	
public class PriorityQueueAsLinkedList extends QueueAsLinkedList
{
  
    public void enqueue(Object obj)
    {
		//to be implemented by students
    }
}