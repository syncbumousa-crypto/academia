package ics202.hw03;

public class SubstituteStrings
{
	public static String substitute(String oldString,String newString,String source)
	    {
	    	return substitute(oldString,newString,source,"");
	    }
    public static String substitute(String old,String new1,String source,String tmp)
        {    
        	if(old.length()>source.length())
        	   {   
        	   	   tmp+=source;
        	       source=tmp;
                   return source;
               }
            else
               {
               	   if(source.substring(0,old.length()).equals(old))
               	         {  
               	         	tmp+=new1;
               	         	return substitute(old,new1,source.substring(old.length()),tmp);
               	         }
               	    else
               	        {
               	           tmp+=source.substring(0,1);
               	           return substitute(old,new1,source.substring(1),tmp);
                        }
                }
        } 
}           