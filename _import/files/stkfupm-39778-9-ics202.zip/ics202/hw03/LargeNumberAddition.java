package ics202.hw03;

import java.io.*;
import ics202.*;

public class LargeNumberAddition
{
	static int num1;
	static int num2;
	static boolean done;
	static StackAsLinkedList list1=new StackAsLinkedList();
	static StackAsLinkedList list2=new StackAsLinkedList();
	static StackAsLinkedList list3=new StackAsLinkedList();
	
	public static void main(String[] args)throws IOException
	{
	    BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
	    while(!done)
	       {
	       	 inputData(reader);
	         calculate(list1,list2,list3);
	       }
    }
	
	public static void inputData(BufferedReader reader)throws IOException
	{
	    int n=0,n2=0;
	    boolean done2=false;
	    System.out.println("Enter your choice");
	    System.out.println("1- Addition\n2- Exit"); 
        while(!done2 && n!=1 && n!=2)
            {
            	try
            	    {
            	    	n=Integer.parseInt(reader.readLine());
            	    	done2=true;
            	    }
                catch(NumberFormatException e)
                    {
                    	System.out.println("Invalid input, try again");
                    }
            }
        done2=false;
        switch(n)
            {
            	case 1:
            	       System.out.println("Enter the first number:");
            	       while(!done2)
            	           {
            	           	   try
            	           	      {
            	           	      	  num1=Integer.parseInt(reader.readLine());
            	           	      	  done2=true;
            	           	      }
            	           	   catch(NumberFormatException e)
            	           	      {
            	           	      	  System.out.println("Invalid input, try again");
            	           	      }
            	           }
            	        done2=false;
            	        System.out.println("Enter the second number:");
            	        while(!done2)
            	           {
            	           	   try
            	           	      {
            	           	      	  num2=Integer.parseInt(reader.readLine());
            	           	      	  done2=true;
            	           	      }
            	           	   catch(NumberFormatException e)
            	           	      {
            	           	      	  System.out.println("Invalid input, try again");
            	           	      }
            	           }
            	        boolean done3=false;
            	        done2=false;
            	        System.out.println("Enter the stack number you want to put the first number in");
            	        while(!done2 && !done3)
            	            {
            	            	try
            	            	    {
            	            	    	n2=Integer.parseInt(reader.readLine());
            	            	    	done2=true;
            	            	    }
            	            	catch(NumberFormatException e)
            	            	    {
            	            	    	System.out.println("Invalid input, try again");
            	            	    }
            	            
            	                if(n2==1)
            	                    {
            	              	        pushNumber(list1,""+num1);
            	              	        pushNumber(list2,""+num2);
	                                    done3=true;
	                                    
	                                }
	                            else if(n2==2)
	                                {
	                          	        pushNumber(list2,""+num1);
	                          	        pushNumber(list1,""+num2);
	                                    done3=true;
	                                    
	                                }
	                            else
	                                 System.out.println("Try again");
	                         }       
	                    break;
	            case 2:
	                    done=true;
	                    break;
	         }
	}       
     
     public static void calculate(StackAsLinkedList l1,StackAsLinkedList l2,StackAsLinkedList list3)
     {
     	if(!done)
     	     {
     	     	calculateSum(list1,list2,list3,0);//recursive method
     	     	print(list3);
     	     }
     }
    
     public static void pushNumber(StackAsLinkedList list,String num)
     {
     	for(int i=0;i<num.length();i++)
     	      list.push(""+num.charAt(i));
     }
     
     public static void calculateSum(StackAsLinkedList list1,StackAsLinkedList list2,StackAsLinkedList list3,int m)
     {
       int n1=0,n2=0;
       if(!list1.isEmpty() || !list2.isEmpty())
          {
          	if(list1.isEmpty())
          	    n1=0;
          	else
          	    n1=Integer.parseInt((String)list1.pop());
          	if(list2.isEmpty())
          	    n2=0;
          	else
          	    n2=Integer.parseInt((String)list2.pop());
          	int k=(n1+n2+m)%10;
          	list3.push(""+k);
          	m=(n1+n2+m)/10;
          	calculateSum(list1,list2,list3,m);
            
          }
     }
     
     public static void print(StackAsLinkedList list)
     {
     	System.out.println("The sum of the two numbers is:");
     	while(!list.isEmpty())
     	     System.out.print(list.pop());
        System.out.println();
     }
}                               
		      
		     	         		