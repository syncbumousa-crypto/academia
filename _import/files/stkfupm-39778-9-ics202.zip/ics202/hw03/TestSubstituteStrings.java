package ics202.hw03;
import java.io.*;

public class TestSubstituteStrings
{
	public static void main(String[] args)throws IOException
	{
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the string:");
		String source=reader.readLine();
		System.out.println("Enter the string you want to replace:");
		String old=reader.readLine();
		System.out.println("Enter the string to want to replace it by:");
		String new1=reader.readLine();
		System.out.println("The new string is as follows:"+SubstituteStrings.substitute(old,new1,source));
		
    }
}