package ics202;

import java.util.NoSuchElementException;

public class GraphAsMatrix extends AbstractGraph {
    protected Edge matrix[][];

    public GraphAsMatrix(int size) {
        super(size);
        matrix = new Edge[size][size];
    }

    protected void addEdge(Edge edge) {
        int v = edge.getV0().getNumber();
        int w = edge.getV1().getNumber();
        if(matrix[v][w] != null)
            throw new InvalidOperationException("duplicate edge");
        if(v == w) {
            throw new InvalidOperationException("loops not allowed");
        } 
        else {
            matrix[v][w] = edge;
            numberOfEdges++;
        }
    }
	
    public Enumeration getEdges() {
        return new Enumeration() {
            protected int v;
            protected int w;

            { //initializer block - finds the first edge
			  search:
                for(v = 0; v < numberOfVertices; v++)
                    for(w = 0; w < numberOfVertices; w++)
                        if(matrix[v][w] != null) 
                           break search;
						
            }

            public boolean hasMoreElements() {
                return v < numberOfVertices && w < numberOfVertices;
            }

            public Object nextElement() {
                if(v >= numberOfVertices || w >= numberOfVertices)
                    throw new NoSuchElementException();
                Edge edge = matrix[v][w];
                for(w++; w < numberOfVertices; w++)
                    if(matrix[v][w] != null)
                        return edge;
				    
                for(v++; v < numberOfVertices; v++)
                    for(w = 0; w < numberOfVertices; w++)
                        if(matrix[v][w] != null)
                            return edge;

               return edge;
            }
        };
    }
	
	public void purge() { //to be implemented by students
	    for(int i=0;i<numberOfVertices;i++)
	         {
	         	for(int j=0;j<numberOfVertices;j++)
	               {
	             	   matrix[i][j]=null;
	               }
	         }
	    super.purge();
	}
	
	public Edge getEdge(int v, int w) { //to be implemented by students
	       if(v<0 || w<0 || v>numberOfVertices-1 || w>numberOfVertices-1)
	             throw new IndexOutOfBoundsException();
	       if(v==w)
	            throw new IllegalArgumentException("Invalid edge");
	       if(matrix[v][w]==null)
	            throw new IllegalArgumentException("No edge found");
	       return matrix[v][w];
	}
	
	public boolean isEdge(int v, int w) {  //to be implemented by students
	      if(v<0 || w<0 || v>numberOfVertices-1 || w>numberOfVertices-1)
	             throw new IndexOutOfBoundsException();
	      if(v==w || matrix[v][w]==null)
	             return false;
	      else 
	             return true;
	}
	
	protected Enumeration getEmanatingEdges(int from) { //to be implemented by students
	       final int i=from;
	       if(i<0 || i>=numberOfVertices)
	            throw new IllegalArgumentException("Invalid vertex");
	       return new Enumeration()
	            {
	            	protected int v=0;
	            	{
	            		search:
	            	    for(;v<numberOfVertices;v++)
	            	      if(matrix[i][v]!=null)
	            	             break search;
	                }
	            	public boolean hasMoreElements()
	            	    {
	            	    	return v<numberOfVertices;
	            	    }
	                 public Object nextElement()
	                    {
	                    	if(v>=numberOfVertices)
	                    	     throw new InvalidOperationException("Stop");
	                    	Edge edge=matrix[i][v];
	                    	for(v++;v<numberOfVertices;v++)
	                    	     if(matrix[i][v]!=null)
	                    	         return edge;
	                    	return edge;
	                   }
	             };
	}
	
	protected Enumeration getIncidentEdges(int to) {  //to be implemented by students
	       final int i=to;
	        if(i<0 || i>=numberOfVertices)
	            throw new IllegalArgumentException("Invalid vertex");
	       return new Enumeration()
	            {
	            	protected int v=0;
	            	{
	            		search:
	            	    for(;v<numberOfVertices;v++)
	            	      if(matrix[i][v]!=null)
	            	             break search;
	                }
	            	public boolean hasMoreElements()
	            	    {
	            	         return v<numberOfVertices;
	            	    }
	            	public Object nextElement()
	            	    {
	            	       if(v>=numberOfVertices)
	            	            throw new IllegalArgumentException("Stop"); 
	                       	Edge edge=matrix[i][v];
	                       	for(v++;v<numberOfVertices;v++)
	                    	     if(matrix[i][v]!=null)
	                    	         return edge;
	                    	return edge;
	            	    }
	            };          
	}
	
    protected int compareTo(MyComparable comparable)  {
        throw new MethodNotImplemented();   // you do not need to implement this.
    }
}
