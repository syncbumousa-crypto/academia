package ics202.hw01;

import ics202.lab01.*;
import ics202.*;

import java.io.*;

class BankAccount extends AbstractObject
{private int accountNumber;
 private String customerName;
 private double balance;
 private boolean zakatable;
 public BankAccount(int accountNumber,String customerName,double balance)
            {this.accountNumber=accountNumber;
             this.customerName=customerName;
             this.balance=balance;
             this.zakatable=false;
            }
 public BankAccount(int accountNumber)
            {this(accountNumber,null,0.0);
             this.zakatable=false;
            }
 public double getBalance()
            {return balance;
            }
 public boolean isZakatable()
            {return zakatable;
            }
 public void setZakatable(boolean status)
            {zakatable=status;
            }
 public void deposit(double amount)
            {balance+=amount;
            }
 public void withDraw(double amount)
            {if(amount<=balance)
                  balance-=amount;
            }
 public String getStatus()
            {if(zakatable==false)
                 return "Unzakatable";
             else return "Zakatable";
            }
 public String toString()
            {return accountNumber+"\t"+customerName+"\t"+balance+"\t"+getStatus();
            }
 public int compareTo(MyComparable obj)
            {BankAccount arg=(BankAccount)obj;
              if(accountNumber>arg.accountNumber)
                    return 1;
              else if(accountNumber <arg.accountNumber)
                    return -1;
              else
                    return 0;
            }

}


class PartitionVisitor extends AbstractVisitor
{private MyContainer zakatable;
 private MyContainer unzakatable;
 public void visit(Object obj)
 {
 boolean check;
       BankAccount arg=(BankAccount)obj;
       check = arg.isZakatable();
        if(check)
           zakatable.insert(arg);
        else
           unzakatable.insert(arg);
       }
 public MyContainer getZakatable()
       {return zakatable;
       }
 public MyContainer getUnzakatable()
       {return unzakatable;
       }
}

class ZakatVisitor extends AbstractVisitor
{public void visit(Object obj)
    {BankAccount account;
     if(obj instanceof BankAccount)
         { account=(BankAccount)obj;
           if(account.isZakatable()&&account.getBalance()>=4000.0)
                 account.withDraw(0.025*account.getBalance());
         }
    }
}

public class BankAccountSystem
{public static void main(String[] args)throws IOException
    {BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
     MyContainer container=new MyContainer();
     boolean done=false;
     int number=0;
     boolean finish=false;
     while(!finish)
        {System.out.println("Enter your choice:\n"+"1-Create an account\n"+
                                               "2-Make deposit\n"+
                                               "3-Make withdrawl\n"+
                                               "4-Set Zakatable\n"+
                                               "5-Partition accounts\n"+
                                               "6-Pay zakat\n"+
                                               "7-Print all accounts\n"+
                                               "8-Exit"
                           ); 
         while(!done)
             {try
                  {number=Integer.parseInt(reader.readLine());
                   done=true;
                  }
              catch(NumberFormatException n)
                 {System.out.println("Wrong input");
                 }
             }
         if(number==1)
               {System.out.println("Enter account number");
                int n=Integer.parseInt(reader.readLine());
                System.out.println("Enter customer name");
                String name=reader.readLine();
                System.out.println("Enter the balance in your account");
                double balance=Double.parseDouble(reader.readLine());
                BankAccount account=new BankAccount(n,name,balance);
                container.insert(account);
               }
         else if(number==2)
               {System.out.println("Enter account number");
                int num=Integer.parseInt(reader.readLine());
                System.out.println("Enter deposit amount");
                double num2=Double.parseDouble(reader.readLine());
                BankAccount nAccount=new BankAccount(num);
                Enumeration enu=container.getEnumeration();
                while(enu.hasMoreElements())
                    {if(((BankAccount)enu.nextElement()).isEQ(nAccount))
                        nAccount.deposit(num2);
                    }
               }
         else if(number==3)
               {System.out.println("Enter account number");
                int num=Integer.parseInt(reader.readLine());
                BankAccount nAccount=new BankAccount(num);
                System.out.println("Enter account number");
                double amount=Double.parseDouble(reader.readLine());
                Enumeration enu=container.getEnumeration();
                while(enu.hasMoreElements())
                    {if(((BankAccount)enu.nextElement()).isEQ(nAccount))
                        nAccount.withDraw(amount);
                    }
               }
         else if(number==4)
              {System.out.println("Enter an account number");
               int num=Integer.parseInt(reader.readLine());
               BankAccount account=new BankAccount(num);
               done=false;
               Enumeration enu=container.getEnumeration();
               while(enu.hasMoreElements())
                   { if(((BankAccount)enu.nextElement()).isEQ(account))
                        {while(!done)
                            {System.out.println("Do you want to make your account zakatable?T/F");
                             String r=reader.readLine();
                             if((!r.equalsIgnoreCase("T"))&&(!r.equalsIgnoreCase("F")))
                                    System.out.println("Wrong input");
                             else if(r.equalsIgnoreCase("T"))
                                   { account.setZakatable(true);
                                     done=true;
                                   }
                             else if(r.equalsIgnoreCase("F"))
                                    {account.setZakatable(false);
                                     done=true;
                                    }
                            }
                        }
                    }
               }
         else if(number==5)
              {Visitor visitor=new PartitionVisitor();
               Visitor visitor2=new PrintingVisitor();
               Enumeration go=container.getEnumeration();
               while(go.hasMoreElements())
                     visitor.visit(go.nextElement());
               MyContainer zk1=visitor.getZakatable();
               MyContainer zk2=visitor.getUnzakatable();
               Enumeration m1=zk1.getEnumeration();
               Enumeration m2=zk2.getEnumeration();
               while(m1.hasMoreElements())
                     visitor2.visit(m1.nextElement());
               while(m2.hasMoreElements())
                     visitor2.visit(m2.nextElement());
              }
         else if(number==6)
              {
              }
         else if(number==7)
              {
              }
         else if(number==8)
              {finish=true;
              }
        } 
   }
} 
 
 
