package ics202;

public interface Digraph extends Graph
{
    public abstract boolean isStronglyConnected();
    public abstract void topologicalOrderTraversal(Visitor visitor);
}
