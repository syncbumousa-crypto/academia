Hi KFUPMers,,

This is the test bank for MIS215

Book:
Introduction to Information Systems,
Edition:
15th Edition
by:
James A. O'Brien, George Marakas

Good Luck in your Examz

Fahad Maddah
:)