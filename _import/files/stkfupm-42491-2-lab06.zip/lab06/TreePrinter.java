package ics202.lab06;

import ics202.*;

public class TreePrinter implements PrePostVisitor {
	public void preVisit(Object obj) {
		System.out.print("{");
	}
	
	public void inVisit(Object obj) {
		System.out.print(obj);
	}
	
	public void postVisit(Object obj) {
		System.out.print("}");
	}
	
	public boolean isDone() {
		return false;
	}
}